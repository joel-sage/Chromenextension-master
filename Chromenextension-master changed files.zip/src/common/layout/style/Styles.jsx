/* eslint-disable no-unused-vars */
import styled from "styled-components";



export const MainContainer = styled.div`
background-image:url(../bg.gif);
background-position:center;
background-size:cover;
`;
