/* eslint-disable no-unused-vars */
import React from 'react'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import Home from '../pages/Home'
import Governance from '../pages/Governance'
import NotFound from '../pages/NotFound'
import Activities from '../pages/Activities'
import ProgressBar from "../pages/ProgressBar"
import SendHadera from '../pages/SendHadera'
import Nfts from '../pages/Nfts'
import NftSwap from '../pages/NftSwap';
import TokenSwap from '../pages/TokenSwap';
function MainRouter() {
    return (
        <MemoryRouter>
            <Routes>
                <Route path='/' element={<Home />} />
                <Route path='/tokenSwap' element={<TokenSwap />} />
                <Route path='/nftswap' element={<NftSwap />} />
                <Route path='/tikenswap' element={<NftSwap />} />
                <Route path='/activities' element={<Activities />} />
                <Route path='/send' element={<SendHadera />} />
                <Route path='/nft' element={<Nfts />} />
                {/* <Route path='/progress' element ={<ProgressBar/>} />  */}
                <Route path='/governance' element={<Governance />} />
            </Routes>
        </MemoryRouter>
    )
}

export default MainRouter