import React from 'react'

function AnimatedRouter() {
  return (
    <div>AnimatedRouter</div>
  )
}

export default AnimatedRouter