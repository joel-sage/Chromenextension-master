/* eslint-disable no-unused-vars */
import React from 'react'
import MainRouter from '../routers/MainRouter'

function MainProvider() {
  return <MainRouter />
}

export default MainProvider