/* eslint-disable no-unused-vars */
import React, { useState } from 'react';
import MainLayout from '../layout/MainLayout';
import 'react-spring-bottom-sheet/dist/style.css'
import * as Smain from '../../common/layout/style/Styles';
import * as S from './style/Styles'
import Footer from '../layout/Footer';
import NavBar from '../layout/NavBar';
import QRCode from 'react-qr-code';
import { GlobalStyling } from '../globalStyles/Global';
import { MdCopyAll, MdRemoveRedEye, MdFileUpload, MdDownload, MdClose, MdOutlineNavigation, MdAdd } from "react-icons/md";
import { LuStars } from 'react-icons/lu';
import { useNavigate } from 'react-router-dom';
import { BottomSheet } from 'react-spring-bottom-sheet';

const allTokens = [
    { id: 1, name: "HEDERA", price: 759302 },
    { id: 2, name: "CANON", price: 298943 },
    { id: 3, name: "PANDA", price: 483894 }
]
function Home() {
    const [show, setShow] = useState(false);
    const [showSendSheet, setShowSendSheet] = useState(false);
    const [qrCodeValue, setQrcodeValue] = useState('7fdfg87ugfbgd7fuf8473e87g87tgfei8nisudviudu98sd');
    const [tokens, setTokens] = useState(allTokens)
    function showFn() {
        setShow(!show)
    }

    const navigate = useNavigate();
    const insertCommas = n => n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    return (
        <Smain.MainContainer className='container w-[330px] h-[640px] relative'>
            <div className='w-full h-full backdrop-blur-2xl bg-black/80'>
                <div className='h-[280px] w-full bg-[#121213] rounded-b-[45px]'>
                    <div id='CUSTOM_NAVBAR' className='h-[60px] w-full flex justify-between gap-1'>
                        <div className='h-full w-fit bg-[#72727200] px-4 flex items-center'>
                            <div className='h-[39px] w-fit border-[3px] border-[#1d2935] rounded-[30px] flex items-center px-[5px] pr-2'>
                                <img src='../hederaImage.png' className='h-[30px] w-[30px] object-contain' />
                                <h2 className='font-bold text-[#bdbcbc]'>HEDERA</h2>
                            </div>
                        </div>
                        <div className='h-full w-fit flex items-center px-3'>
                            <div className='h-[40px] w-[40px] flex items-center justify-center rounded-full border-[3px] border-[#1d2935]'>
                                <LuStars size={20} color='gray' />
                            </div>
                        </div>
                    </div>
                    <div className="w-[90%] h-[2px] mx-auto bg-[#767676]"></div>
                    <div id='DESC' className='h-fit w-full py-3 text-center'>
                        <p className='font-thin text-[#737373]  text-[12px]'>Available Wallet Balance</p>
                        <h1 className='flex text-[#717171] font-bold text-[30px] w-full justify-center items-baseline'>$ <p className='text-[#fff] text-[25px] px-1'> {insertCommas(23457)} </p></h1>
                    </div>
                    <div id='NETWORK' className='w-full h-fit flex items-center justify-center'>
                        <div className='h-[40px] w-fit p-[6px] flex items-center bg-[#1d1d1d] border-[2px] border-[#333333] rounded-[20px]'>
                            <div className="h-[30px] w-[30px] rounded-full bg-[#2e2e2e]"></div>
                            <p className='text-[#fff] ml-2'>Smart Chain BEP - 20</p>
                        </div>
                    </div>
                    <div id='BUTTONS' onClick={() => setShowSendSheet(!showSendSheet)} className='h-fit py-3 flex items-center justify-center gap-4'>
                        <button className="flex gap-2 items-center justify-center font-bold text-[#fff] h-[45px] w-[120px] bg-[#212121] rounded-[10px]">
                            <MdOutlineNavigation size={20} className='text-white' />
                            SEND
                        </button>
                        <button className="flex gap-2 items-center justify-center h-[45px] w-[120px] rounded-[10px] bg-gradient-to-r from-green-400 to-blue-500 font-bold text-white">
                            <MdOutlineNavigation size={20} className='rotate-180' />
                            RECIEVE
                        </button>
                    </div>
                </div>
                <div id='TOKENS' className='w-full py-2 px-4 flex items-center justify-between'>
                    <p className='text-whtie font-bold text-[#fff]'>TOKENS</p>
                    <div className='h-fit w-fit p-1 px-4 gap-2 transition-[.4s] flex items-center text-white hover:cursor-pointer hover:bg-[#191b1a] hover:scale-[0.95] border-[#545454] border-[2px] rounded-[10px]'>
                        <MdAdd size={20} />
                        <p className='text-[10px] text-[#ccc]'>IMPORT</p>
                    </div>
                </div>
                <S.ScrollBar className='w-full h-[230px] px-3 overflow-y-scroll'>
                    <div className='w-full h-fit flex flex-col gap-2'>

                        {tokens.map((token) =>
                            <div className='h-[100px] w-full flex items-center p-[7px] border-[2px] border-[#2a2a2a] rounded-[20px] bg-[#121212] first-letter:first-line:marker:'>
                                <div className='h-[85px] w-[47px] flex items-center justify-center bg-[#232323] rounded-[15px]'>
                                    <img src='../hederaImage.png' className='h-[30px] w-[30px] object-contain' />
                                </div>
                                <div className='flex flex-col flex-1 h-full'>
                                    <div className="flex items-center justify-between px-3 text-white">
                                        <h1 className='font-bold'>{ token.name }</h1>
                                        <p className='text-[#b3b3b3] flex items-baseline font-bold'>$ <p className='text-[12px] font-thin ml-1 text-[#fff]'>{insertCommas(token.price)}</p> </p>
                                    </div>
                                    <div className='flex flex-1 items-center justify-center'>
                                        <div className='h-[90%] w-[95%] flex items-center justify-center bg-[#262625] rounded-lg'>
                                            <p className='text-[10px] text-white'>CHART GOES HERE</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                </S.ScrollBar>


                <BottomSheet skipInitialTransition open={showSendSheet} snapPoints={({ minHeight, maxHeight }) => [minHeight, maxHeight / 0.7]} className='--rsbs-bg-transparent' >
                    <div className='bg-[#000000] rounded-2xl'>
                        <div className='h-14 border-b border-b-slate-200 w-full flex items-center '>
                            <div onClick={() => setShowSendSheet(!showSendSheet)} className='w-8 p-2 h-8 ml-1 mr-14 flex justify-center items-center border border-slate-300/50 rounded-full '><MdClose size={20} className='text-white cursor-pointer' /></div>
                            <div className='w-8/12 text-lg tracking-wider font-bold text-white'>Make a deposit</div>
                        </div>

                        <div className='h-fit w-full py-10 flex justify-center'>
                            <QRCode value={qrCodeValue} className='h-[200px] w-[200px]' />
                        </div>

                        <div className='h-fit w-full pb-8 flex items-center justify-center'>
                            <div className='p-2 px-4 rounded-[50px] bg-[#fff]'>
                                <p>{qrCodeValue}</p>
                            </div>
                        </div>

                        <div className='h-fit w-full pb-8 flex items-center justify-center'>
                            <div className="h-fit w-[90%] border-[#ff9900] bg-[#ff99008c] text-white border-[2px] p-2 rounded-xl">
                                Please scan the your QR-code above to copy your wallet address an proceed to deposit,
                                additionaly you may also do other thing with
                            </div>
                        </div>
                    </div>
                </BottomSheet>
                <Footer />
            </div>
        </Smain.MainContainer>
    )
}

export default Home