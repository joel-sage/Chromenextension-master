import { createGlobalStyle } from "styled-components";

export const GlobalStyling = createGlobalStyle(`
    body{
      font-family:Roboto , san-serif;

  }



`)